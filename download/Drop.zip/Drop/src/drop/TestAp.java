package drop;

import java.awt.Frame;

import processing.awt.PSurfaceAWT.SmoothCanvas;
import processing.core.PApplet;

public class TestAp extends PApplet {

	SDrop drop;

	public void settings() {
		size(400, 400);
	}

	public void setup() {
		drop = new SDrop(this);
	}

	public static void main(String[] args) {
		PApplet.main("drop.TestAp", new String[] {});
	}

	public void dropEvent(DropEvent theDropEvent) {
		// returns a string e.g. if you drag text from a texteditor
		// into the sketch this can be handy.
		println("toString()\t" + theDropEvent.toString());

		// returns true if the dropped object is an image from
		// the harddisk or the browser.
		println("isImage()\t" + theDropEvent.isImage());

		// returns true if the dropped object is a file or folder.
		println("isFile()\t" + theDropEvent.isFile());

		// if the dropped object is a file or a folder you
		// can access it with file() . for more information see
		// http://java.sun.com/j2se/1.4.2/docs/api/java/io/File.html
		println("file()\t" + theDropEvent.file());

		// returns true if the dropped object is a bookmark, a link, or a url.
		println("isURL()\t" + theDropEvent.isURL());

		// returns the url as string.
		println("url()\t" + theDropEvent.url());

		// returns the DropTargetDropEvent, for further information see
		// http://java.sun.com/j2se/1.4.2/docs/api/java/awt/dnd/DropTargetDropEvent.html
		println("dropTargetDropEvent()\t" + theDropEvent.dropTargetDropEvent());
	}
}
